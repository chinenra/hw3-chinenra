package cs201Assignment3;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DBHelper {

	Connection conn = null;
	Statement st = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	public DBHelper() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment3torie?user=root&password=sherlockkudo");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean checkIfUserExists(String username) {
		boolean userExists = false;
		
		System.out.println("Checking " + username + "> exists.");

		try {
			ps = conn.prepareStatement("SELECT * FROM users WHERE username = ?");
			ps.setString(1, username);
			rs = ps.executeQuery();
			
			while (rs.next()) {
				userExists = true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
				
		return userExists;
	}
	
	public void insertUser(String username, String password) {

		System.out.println("Inserting <" + username + "> with password <" + password + ">.");
		
		try {
			ps = conn.prepareStatement("INSERT INTO users (username, password) VALUES (?, ?)");
			ps.setString(1, username);
			ps.setString(2, password);
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	public boolean loginUser(String username, String password) {
		System.out.println("Checking <" + username + "> with password <" + password + ">.");
		
		try {
			ps = conn.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?");
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();
			
			//checking if password matches username
			while (rs.next()) {
				return true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
				
		return false;
	}
	
	public void addToSearchHistory(String username, String searchQuery) {
		
		long timestamp = System.currentTimeMillis() / 1000L;
		
		try {
			ps = conn.prepareStatement("INSERT INTO search_history (username, search_query, timestamp) VALUES (?, ?, ?)");
			ps.setString(1, username);
			ps.setString(2, searchQuery);
			ps.setString(3, String.valueOf(timestamp));
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<String> getSearchHistory(String username) {
		ArrayList<String> searchHistory = new ArrayList<String>();
		
		try {
			ps = conn.prepareStatement("SELECT * FROM search_history WHERE username = ? ORDER BY id DESC");
			ps.setString(1, username);
			rs = ps.executeQuery();
			
			while (rs.next()) {
				searchHistory.add(rs.getString("search_query"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
				
		
		return searchHistory;
	}
}
