package cs201Assignment3;

import java.util.ArrayList;

public class WeatherReader {
	
	
	public String city, state, country, sunriseTime, sunsetTime;
	public double latitude, longitude;
	public int currentTemperature, dayLow, dayHigh, humidity, windDirection;
	public float pressure, visibility, windspeed;
	public ArrayList<String> conditionsDescription = new ArrayList<String>();

	public boolean isValidCity = true;
	
	public WeatherReader(String cityInfoLine) {
		
		System.out.println(cityInfoLine);
		
		String[] cityInfo = cityInfoLine.split("\\|");
		
		int cityInfoLength = cityInfo.length;
		
		if(cityInfoLength < 16) {
			isValidCity = false;
		} else {
			int numberOfConditions = cityInfoLength - 15;

			this.city = cityInfo[0];
			this.state = cityInfo[1];
			this.country = cityInfo[2];
			
			// latitude, longitude
			try {								
				this.latitude = Double.parseDouble(cityInfo[3]);
				this.longitude = Double.parseDouble(cityInfo[4]);								
			} catch(NumberFormatException nfe) {
				isValidCity = false;
			}

			this.sunriseTime = cityInfo[5];
			this.sunsetTime = cityInfo[6];
			
			// currentTemperature
			try {
				this.currentTemperature = Integer.parseInt(cityInfo[7]);
			} catch(NumberFormatException nfe) {
				isValidCity = false;
			}

			// dayLow, dayHigh, humidity
			try {
				this.dayLow = Integer.parseInt(cityInfo[8]);
				this.dayHigh = Integer.parseInt(cityInfo[9]);
				this.humidity = Integer.parseInt(cityInfo[10]);
			}  catch(NumberFormatException nfe) {
				isValidCity = false;
			}

			// pressure, visibility, windspeed
			try {
				this.pressure = Float.parseFloat(cityInfo[8]);
				this.visibility = Float.parseFloat(cityInfo[9]);
				this.windspeed = Float.parseFloat(cityInfo[10]);
			}  catch(NumberFormatException nfe) {
				isValidCity = false;
			}

			// conditionDescriptions
			for(int i = 0; i < numberOfConditions; i++) {
				int conditionIndex = 9 + i;
				this.conditionsDescription.add(cityInfo[conditionIndex]);
			}

			// Done parsing
		}
	}
}
